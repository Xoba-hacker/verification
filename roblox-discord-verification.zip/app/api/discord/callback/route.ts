import { type NextRequest, NextResponse } from "next/server"

const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID || "1456686787819868400"
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || ""

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const code = searchParams.get("code")

    console.log("[v0] Discord OAuth callback received, code present:", !!code)

    if (!code) {
      return NextResponse.redirect(new URL("/?error=no_code", req.url))
    }

    const redirectUri = process.env.NEXT_PUBLIC_REDIRECT_URI || `${req.headers.get("origin")}/api/discord/callback`

    console.log("[v0] Exchanging code for token with redirect URI:", redirectUri)

    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    })

    const tokenData = await tokenResponse.json()

    console.log("[v0] Token response status:", tokenResponse.status)

    if (!tokenData.access_token) {
      console.log("[v0] Token error:", tokenData)
      return NextResponse.redirect(new URL("/?error=token_failed", req.url))
    }

    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
      },
    })

    const userData = await userResponse.json()
    console.log("[v0] User data received, ID:", userData.id)

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Redirecting...</title>
        </head>
        <body>
          <script>
            console.log("[v0] Storing Discord user data in sessionStorage");
            sessionStorage.setItem('discord_user_id', ${JSON.stringify(userData.id)});
            sessionStorage.setItem('oauth_complete', 'true');
            console.log("[v0] Redirecting to verification page");
            window.location.href = '/?oauth=complete';
          </script>
        </body>
      </html>
    `

    return new NextResponse(html, {
      headers: {
        "Content-Type": "text/html",
      },
    })
  } catch (error) {
    console.error("[v0] Discord callback error:", error)
    return NextResponse.redirect(new URL("/?error=server_error", req.url))
  }
}
